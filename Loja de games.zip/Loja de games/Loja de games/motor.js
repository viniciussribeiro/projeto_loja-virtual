var produto1;
var produto2;
var produto3;
var produto4;
var produto5
var preco1;
var preco2;
var preco3;
var preco4;
var preco5;
var soma;

function Calc() {
	if (document.getElementById('produto1').checked==true) {
		produto1 = document.getElementById('NomeProduto1').value;
		preco1 = parseInt(document.getElementById('PrecoProduto1').value);
		document.getElementById('resultado').textContent = "O total do produto "+produto1+ " é: R$"+preco1+".00";
	} else if (document.getElementById('produto2').checked==true) {
		produto1 = document.getElementById('NomeProduto1').value;
		preco1 = parseInt(document.getElementById('PrecoProduto1').value);
		produto2 = document.getElementById('NomeProduto2').value;
		preco2 = parseInt(document.getElementById('PrecoProduto2').value);
		soma = preco1 + preco2;
		document.getElementById('resultado').textContent = "O total dos produtos "+produto1+", "+produto2+ " é: R$"+soma+".00";
	} else if (document.getElementById('produto3').checked==true) {
		produto1 = document.getElementById('NomeProduto1').value;
		preco1 = parseInt(document.getElementById('PrecoProduto1').value);
		produto2 = document.getElementById('NomeProduto2').value;
		preco2 = parseInt(document.getElementById('PrecoProduto2').value);
		produto3 = document.getElementById('NomeProduto3').value;
		preco3 = parseInt(document.getElementById('PrecoProduto3').value);
		soma = preco1 + preco2 +preco3;
		document.getElementById('resultado').textContent = "O total dos produtos "+produto1+", "+produto2+", "+produto3+" é: R$"+soma+".00";
	} else if (document.getElementById('produto4').checked==true) {
		produto1 = document.getElementById('NomeProduto1').value;
		preco1 = parseInt(document.getElementById('PrecoProduto1').value);
		produto2 = document.getElementById('NomeProduto2').value;
		preco2 = parseInt(document.getElementById('PrecoProduto2').value);
		produto3 = document.getElementById('NomeProduto3').value;
		preco3 = parseInt(document.getElementById('PrecoProduto3').value);
		produto4 = document.getElementById('NomeProduto4').value;
		preco4 = parseInt(document.getElementById('PrecoProduto4').value);
		soma = preco1 + preco2 +preco3+preco4;
		document.getElementById('resultado').textContent = "O total dos produtos "+produto1+", "+produto2+", "+produto3+", "+produto4+" é: R$"+soma+".00";
	} else if (document.getElementById('produto5').checked ==true) {
		produto1 = document.getElementById('NomeProduto1').value;
		preco1 = parseInt(document.getElementById('PrecoProduto1').value);
		produto2 = document.getElementById('NomeProduto2').value;
		preco2 = parseInt(document.getElementById('PrecoProduto2').value);
		produto3 = document.getElementById('NomeProduto3').value;
		preco3 = parseInt(document.getElementById('PrecoProduto3').value);
		produto4 = document.getElementById('NomeProduto4').value;
		preco4 = parseInt(document.getElementById('PrecoProduto4').value);
		produto5 = document.getElementById('NomeProduto5').value;
		preco5 = parseInt(document.getElementById('PrecoProduto5').value);
		soma = preco1 + preco2 + preco3 +preco4+preco5;
		document.getElementById('resultado').textContent = "O total dos produtos "+produto1+", "+produto2+", "+produto3+", "+produto4+", "+produto5+" é: R$"+soma+".00";
	}
}